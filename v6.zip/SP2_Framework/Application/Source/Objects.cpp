#include "Objects.h"


CObjects::CObjects(void)
{
}


CObjects::~CObjects(void)
{
}

int CObjects::getTotal(void)
{
	return translateVal.size();
}
