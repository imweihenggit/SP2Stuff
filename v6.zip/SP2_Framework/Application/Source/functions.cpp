#include "functions.h"

bool Collision(Vector3 charPos, std::vector<CObjects> objList)
{
	float charRad = 5;

		for (int i = 0; i < objList.size(); ++i)
		{
			for (int j = 0; j < objList[i].collisionPos.size(); ++j)
			{
				if ((charPos-objList[i].collisionPos[j]).Length() <= (charRad + objList[i].collisionRad))
				{
					return true;
				}
			}
		}
	
	return false;
}