#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <vector>
#include"MatrixStack.h"

bool Collision(Vector3 charPos, std::vector<Vector3> sphere, std::vector<float> rad);

#endif