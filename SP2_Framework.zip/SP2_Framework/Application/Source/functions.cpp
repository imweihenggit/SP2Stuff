#include "functions.h"

bool Collision(Vector3 charPos, std::vector<Vector3> sphere, std::vector<float> rad)
{
	float charRad = 5;

		for (int i = 0; i < sphere.size(); ++i)
		{
			if ((charPos-sphere[i]).Length() <= (charRad + rad[i]))
			{
				return true;
			}
		}
	
	return false;
}